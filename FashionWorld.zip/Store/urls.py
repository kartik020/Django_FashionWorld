from django.contrib import admin
from django.urls import path
from Store.view.home import Index
from Store.view.login import Login, logout
from Store.view.signup import Signup
from Store.view.cart import Cart
from Store.view.checkout import CheckOut
from Store.view.orders import OrderView
from .middlewares.auth import auth_middleware

urlpatterns = [
    path('', Index.as_view(), name='Homepage'),
    path('signup', Signup.as_view(), name='signup'),
    path('login', Login.as_view(), name='login'),
    path('logout', logout, name='logout'),
    path('cart', Cart.as_view(), name='cart'),
    path('check-out', CheckOut.as_view(), name='checkout'),
    path('orders', auth_middleware(OrderView.as_view()), name='orders')
]
